package com.ll.spirits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpiritsApplicationTests {

	@Test
	void contextLoads() {
	}

}
